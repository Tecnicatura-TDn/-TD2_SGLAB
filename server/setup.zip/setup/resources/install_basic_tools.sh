# Instala paquetes básicos
#    install_basic_tools() {
#        log "Instalando herramientas básicas..."
#        case "$OS" in
#            ubuntu|debian)
#                sudo apt-get install -y -qq git curl wget rsync openssh-client openssh-server \
#                    software-properties-common apt-transport-https ca-certificates \
#                   gnupg-agent unzip make nano htop vim
#                ;;
#            centos|rhel|fedora)
#                sudo yum install -y -q git curl wget rsync openssh-clients openssh-server \
#                    unzip nano htop vim
#                ;;
#        esac
#    }

install_basic_tools() {
    log "Instalando herramientas básicas..."
    case "$OS" in
        ubuntu|debian)
            sudo apt-get install -y -qq git curl wget rsync openssh-client openssh-server \
                ca-certificates gnupg unzip make nano htop vim
            ;;
        centos|rhel|fedora)
            # Detecta automáticamente si existe dnf, sino usa yum como respaldo
            if command -v dnf &> /dev/null; then
                PKG_MANAGER="dnf"
            else
                PKG_MANAGER="yum"
            fi
            
            sudo "$PKG_MANAGER" install -y -q git curl wget rsync openssh-clients openssh-server \
                unzip nano htop vim
            ;;
    esac
}