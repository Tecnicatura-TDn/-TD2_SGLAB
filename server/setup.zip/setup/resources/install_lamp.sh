# INSTALACIONES DE LAMP
install_apache() {
    log "Instalando el servidor web Apache2..."
    sudo apt-get install -y -qq apache2
    log "Apache2 instalado correctamente."
}

install_mysql() {
    log "Instalando MySQL Server..."
    sudo apt-get install -y -qq mysql-server
    log "MySQL Server instalado correctamente."
}

install_php() {
    log "Agregando el repositorio PPA de Ondřej Surý para PHP 8.3..."
    sudo add-apt-repository ppa:ondrej/php -y > /dev/null
    sudo apt-get update -qq

    log "Instalando PHP 8.3 y extensiones (incluyendo mysqli)..."
    sudo apt-get install -y -qq php8.3 libapache2-mod-php8.3 php8.3-mysql
    log "PHP 8.3 instalado y configurado para Apache."
}

finalize_lamp_setup() {
    log "Reiniciando Apache2 para aplicar la configuración de PHP..."
    sudo systemctl restart apache2

    log "Creando una página de prueba de PHP para verificar la instalación..."
    echo "<?php phpinfo(); ?>" | sudo tee /var/www/html/info.php > /dev/null
}


provision_lamp_stack() {
    if [ "$OS" != "ubuntu" ] && [ "$OS" != "debian" ]; then
        error "El aprovisionamiento LAMP está optimizado para Ubuntu/Debian."
    fi
    log "Iniciando aprovisionamiento de un servidor LAMP clásico..."
    install_apache
    install_mysql
    install_php
    finalize_lamp_setup

    SERVER_IP=$(hostname -I | awk '{print $1}')
    log "¡Aprovisionamiento LAMP completado exitosamente!"
    info "Accede a la página de prueba en tu navegador: http://$SERVER_IP/info.php"
    warn "Por seguridad, recuerda asegurar tu instalación de MySQL ejecutando: sudo mysql_secure_installation"
    warn "Una vez verificado todo, elimina el archivo de prueba con: sudo rm /var/www/html/info.php"
}
