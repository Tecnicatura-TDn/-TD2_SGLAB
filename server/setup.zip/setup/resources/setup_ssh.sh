# Configurar SSH
setup_ssh() {
    log "Configurando SSH..."
    # ... (código de configuración de SSH original)
}

# 
setup_github_ssh() {
    log "Configurando acceso SSH a GitHub..."
    # ... (código de configuración de GitHub SSH original)
}
