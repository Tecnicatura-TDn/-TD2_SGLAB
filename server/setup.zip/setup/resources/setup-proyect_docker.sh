
# --- Funciones para el Entorno Docker + Laravel ---

install_docker() {
    log "Instalando Docker..."
    if command -v docker &> /dev/null; then
        warn "Docker ya está instalado"
        return
    fi
    # ... (código de instalación de Docker original)
}

install_docker_compose() {
    log "Instalando Docker Compose..."
    if command -v docker-compose &> /dev/null; then
        warn "Docker Compose ya está instalado"
        return
    fi
    # ... (código de instalación de Docker Compose original)
}

clone_repository() {
    local repo_url=$1
    local target_dir=${2:-"/opt/laravel-app"}
    # ... (código para clonar repositorio original)
}

setup_project() {
    log "Configurando el proyecto Laravel..."
    # ... (código de configuración del proyecto Laravel original)
}

# Funcion main de docker
provision_docker_laravel() {
    log "Iniciando aprovisionamiento para entorno de desarrollo Laravel con Docker..."
    install_docker
    install_docker_compose
    setup_ssh
    setup_github_ssh
    
    read -p "Introduce la URL SSH de tu repositorio GitHub (ej: git@github.com:usuario/repo.git): " repo_url
    if [ -z "$repo_url" ]; then
        error "Debes proporcionar una URL de repositorio válida"
    fi
    
    clone_repository "$repo_url"
    setup_project
    
    log "Provisionamiento completado exitosamente!"
    info "Acceso a la aplicación: http://localhost"
    info "Acceso a PHPMyAdmin: http://localhost:8080"
    warn "Recuerda que has tenido que agregar manualmente la clave SSH a tu cuenta de GitHub."
}